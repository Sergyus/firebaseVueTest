
### Documentation

Documentation (updated for v2.0): https://zawiastudio.com/dashboard/docs

ChangeLog (currently v2.0): https://zawiastudio.com/dashboard/changelog
