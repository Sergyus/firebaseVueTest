// Notifications:
export const NOTIFY_INFO_ON = 'notificationInfoOn'
export const NOTIFY_INFO_OFF = 'notificationInfoOff'

export const NOTIFY_ERROR_ON = 'notificationErrorOn'
export const NOTIFY_ERROR_OFF = 'notificationErrorOff'

export const NOTIFY_SUCCESS_ON = 'notificationSuccessOn'
export const NOTIFY_SUCCESS_OFF = 'notificationSuccessOff'

export const NOTIFY_ALL_OFF = 'notificationsOff'
