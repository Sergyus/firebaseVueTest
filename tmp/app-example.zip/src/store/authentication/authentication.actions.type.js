export const CHECK_AUTH = 'checkAuth'
export const REGISTER = 'register'
export const LOGIN = 'login'
export const LOGOUT = 'logout'
