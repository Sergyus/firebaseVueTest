export const SET_AUTH = 'setAuth'
export const PURGE_AUTH = 'purgeAuth'
