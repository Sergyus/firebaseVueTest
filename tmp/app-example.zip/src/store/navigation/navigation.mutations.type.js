export const SIDENAVIGATION_OPEN = 'sideNavigationOpen'
export const SIDENAVIGATION_CLOSE = 'sideNavigationClose'

export const LOGOUT_OPEN = 'logoutDialogOpen'
export const LOGOUT_CLOSE = 'logoutDialorClose'
