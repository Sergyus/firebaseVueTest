export const GET_BOOK = 'getBook'
export const GET_BOOKS = 'getBooks'
export const CREATE_BOOK = 'createBook'
export const UPDATE_BOOK = 'updateBook'
