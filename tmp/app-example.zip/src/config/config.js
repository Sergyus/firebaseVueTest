export default {}
export const ASSES_BASE_URL = 'http://assets.commercialapplication.mainprospect'
