export default {
  apiKey: 'AIzaSyDogZ_tVo8AwD4bSJFAtzXAvOjdhPKnRM8',
  authDomain: 'fir-app-3355f.firebaseapp.com',
  databaseURL: 'https://fir-app-3355f.firebaseio.com',
  projectId: 'fir-app-3355f',
  storageBucket: 'fir-app-3355f.appspot.com',
  messagingSenderId: '534729007386'
}
